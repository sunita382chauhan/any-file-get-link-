const express = require("express");
const multer = require("multer");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = process.env.PORT || 10000;
const UPLOAD_DIR = path.join(__dirname, "link_generator");

// Ensure upload dir exists
if (!fs.existsSync(UPLOAD_DIR)) {
  fs.mkdirSync(UPLOAD_DIR);
}

// Multer storage config
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, UPLOAD_DIR);
  },
  filename: function (req, file, cb) {
    const uniqueName = Date.now() + "-" + Math.round(Math.random() * 1e9) + path.extname(file.originalname);
    cb(null, uniqueName);
  }
});

const upload = multer({
  storage,
  limits: { fileSize: 100 * 1024 * 1024 } // 100 MB limit
});

// Serve static files if any (not strictly required)
app.use("/static", express.static(path.join(__dirname, "static")));

// Root - upload form (design per screenshot: pink bg + golden button)
app.get("/", (req, res) => {
  res.send(`<!doctype html>
<html>
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Any File Get Link</title>
  <style>
    body {
      margin:0;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial;
      background: linear-gradient(180deg,#ffc3da 0%, #ffb6e0 100%);
      height:100vh;
      display:flex;
      align-items:center;
      justify-content:center;
    }
    .card {
      background: white;
      width: 360px;
      max-width: 92%;
      padding: 28px;
      border-radius: 14px;
      box-shadow: 0 8px 30px rgba(0,0,0,0.12);
      text-align:center;
    }
    h1 { margin: 0 0 10px 0; font-size:20px; color:#333; }
    p { margin: 6px 0 18px 0; color:#555; font-size:14px; }
    .file-input {
      display:block;
      margin: 12px auto;
    }
    .btn {
      display:inline-block;
      background: linear-gradient(180deg,#ffdf7e,#f4b400);
      color:#3a2f00;
      border:none;
      padding:12px 20px;
      border-radius:10px;
      font-weight:700;
      cursor:pointer;
      box-shadow: 0 6px 18px rgba(244,180,0,0.25);
    }
    .linkbox { margin-top:18px; word-break:break-all; background:#f9f9f9; padding:10px; border-radius:8px; display:none; }
    .copy-btn { margin-left:8px; padding:6px 10px; border-radius:6px; cursor:pointer; border:none; background:#eee; }
    .small { font-size:12px; color:#777; margin-top:10px;}
  </style>
</head>
<body>
  <div class="card">
    <h1>Any File Get Link</h1>
    <p>Upload any file (max 100 MB). You'll get a direct download link instantly.</p>
    <form id="uploadForm" action="/upload" method="post" enctype="multipart/form-data">
      <input class="file-input" type="file" name="file" required />
      <button class="btn" type="submit">Generate Link</button>
    </form>

    <div id="result" class="linkbox">
      <div><strong>Direct link:</strong></div>
      <div id="link" style="margin-top:8px"></div>
      <div style="margin-top:8px">
        <button id="copyBtn" class="btn" onclick="copyLink()" style="padding:8px 14px">Copy Link</button>
        <a id="openBtn" class="btn" style="text-decoration:none; margin-left:8px; padding:8px 14px" target="_blank">Open</a>
      </div>
    </div>

    <div id="msg" class="small"></div>
  </div>

<script>
const form = document.getElementById('uploadForm');
const resultBox = document.getElementById('result');
const linkDiv = document.getElementById('link');
const copyBtn = document.getElementById('copyBtn');
const openBtn = document.getElementById('openBtn');
const msg = document.getElementById('msg');

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  msg.textContent = "Uploading... please wait.";
  resultBox.style.display = 'none';
  const fd = new FormData(form);
  try {
    const resp = await fetch('/upload', { method: 'POST', body: fd });
    const text = await resp.text();
    // server returns an HTML blob containing anchor; to make robust, server will respond with JSON when XHR used
    try {
      const data = JSON.parse(text);
      if (data && data.link) {
        showLink(data.link);
      } else {
        msg.textContent = 'Upload failed.';
      }
    } catch(err) {
      // fallback: parse link from text using regex
      const m = text.match(/href="([^"]+)"/);
      if (m && m[1]) {
        showLink(m[1]);
      } else {
        msg.textContent = 'Unexpected server response.';
      }
    }
  } catch (err) {
    console.error(err);
    msg.textContent = 'Upload error: ' + err.message;
  }
});

function showLink(url) {
  linkDiv.innerHTML = '<a href="' + url + '" target="_blank">' + url + '</a>';
  openBtn.href = url;
  resultBox.style.display = 'block';
  msg.textContent = 'Upload successful.';
}

function copyLink() {
  const a = linkDiv.querySelector('a');
  if (!a) return;
  const text = a.href;
  navigator.clipboard.writeText(text).then(() => {
    copyBtn.textContent = 'Copied';
    setTimeout(() => copyBtn.textContent = 'Copy Link', 1500);
  }).catch(() => alert('Copy failed, please copy manually.'));
}
</script>

</body>
</html>
`);
});

// Upload endpoint - returns JSON when XHR used
app.post("/upload", upload.single("file"), (req, res) => {
  const file = req.file;
  if (!file) return res.status(400).send("No file uploaded");
  const downloadLink = `${req.protocol}://${req.get("host")}/download/${file.filename}`;
  // If request is XHR/fetch, send JSON
  if (req.headers['accept'] && req.headers['accept'].includes('application/json')) {
    return res.json({ link: downloadLink });
  }
  // else send simple HTML response (for form submit fallback)
  res.send(\`
    <h2>✅ File uploaded successfully!</h2>
    <p>Direct download link:</p>
    <a href="\${downloadLink}" target="_blank">\${downloadLink}</a>
  \`);
});

// Direct download route
app.get("/download/:filename", (req, res) => {
  const filePath = path.join(UPLOAD_DIR, req.params.filename);
  if (!fs.existsSync(filePath)) return res.status(404).send("File not found");
  res.download(filePath);
});

app.listen(PORT, () => console.log("Server running on port " + PORT));