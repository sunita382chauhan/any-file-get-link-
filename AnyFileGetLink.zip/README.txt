
# Any File Get Link
Simple Node.js + Express file uploader that returns a permanent direct download link.
Designed for quick deploy on Render.com (or any Node hosting).

## Quick start
1. Upload this project to Render (or your host).
2. Install dependencies:
   ```
   npm install
   ```
3. Start:
   ```
   npm start
   ```
4. Open the provided URL, upload a file (<=100 MB) and you'll get a direct download link.

## Notes
- Upload directory: `link_generator`
- File size limit: 100 MB
- Copy Link button available on the UI
